# TITLE: Games are Good For You
#### Video Demo: <https://www.youtube.com/watch?v=FMG-ZA9RZzw>
#### Description:
In my project, I created three games in total followed by a introduction to myself. All of them were done using HTMl, CSS and Javascript.
The homepage consists of instructions on how to play the games in details. Under "Click Here" header, three links are provided for navigating to the three respective games.
In each webpage, links to the instruction and other games except the current one is provided for easy navigation. All of them consist of another link called "Get To Know The Developer Here", which will redirect you to a webpage with an introduction to myself in it.
The introductory webpage also consists of several links associated to my interests, favorites and accolades.
The links to all the previous webpages are provided under the remainder of the webpages too for much smoother experience.

Information Regarding Used Files:

Directory "/static" consists of all the CSS files which are linked to various HTML files.
"index.html" is the homepage. Instructions to the games are provided through it. "/static/styles.css" is attached to it.
"simon.html" consists of the game "Simon Says". The dynamic property of the game is generated through Javascript inside it. "/static/simon.css" is attached to it.
"rock.html" consists of the game "Rock Paper Scissors". The dynamic property of the game is generated through Javascript inside it. "/static/style.css" is attached to it.
"snake.html" consists of the game "Snake Xenzia". The dynamic property of the game is generated through Javascript inside it. "/static/snake.css" is attached to it.
"intro.html" introduces you to myself. My primary introduction is displayed through it. "To be used.jpg" is attached to that webpage which is a picture of mine! "/static/work.css" is attached to it.
"interests.html" introduces you to my interests. "/static/work.css" is attached to it.
"favourites.html" introduces you to my favourite things in life. All of my favourites are arranged in a table format. "/static/work.css" is attached to it.
"accolades1.html" portrays a glimpse of my various achievements in numerous Olympiads. "accolade.jpg" is attached to that webpage which is a picture of three crests that I won in Science Festival of my College! "/static/work.css" is attached to it.
"accolades2.html" portrays a glimpse of my achievements in various Quizzes. "sir 3.jpg" is attached to it which is a picture of me receiving a medal from my Respectable Principal Sir! "/static/work.css" is attached to it.